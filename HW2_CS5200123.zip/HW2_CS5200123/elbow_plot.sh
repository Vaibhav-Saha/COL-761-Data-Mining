$(module purge)
$(module load compiler/gcc/9.1.0)
$(module load apps/anaconda/3)

python3 kmeans.py $1 $3




