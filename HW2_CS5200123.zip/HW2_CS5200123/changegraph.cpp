#include <bits/stdc++.h>
using namespace std;

int gspanGaston(string inputfile,string outputfile){
    string line;
    ifstream myfile (inputfile);
    ofstream outfile (outputfile);
    int num=0;
    int num1=1;
    map<string,int> mpp;
    if (myfile.is_open() && outfile.is_open())
    {
        while(getline(myfile,line)){
            vector<vector<string>> vec;
            outfile<<"t # "<<to_string(num)<<endl;
            getline(myfile,line);
            int i=stoi(line);
            while (i)
            {
                getline(myfile,line);
                int var=0;
                if(mpp.find(line)==mpp.end()){
                    mpp[line]=num1;
                    num1++;
                }
                var=mpp[line];
                vec.push_back({"v",to_string(var)});
                i--;
            }
            int j=0;
            while(j<vec.size()){
                if(vec[j][0]=="v")
                outfile<<vec[j][0]<<" "<<to_string(j)<<" "<<vec[j][1]<<endl;
                j++;
            }
            vec.clear();
            getline(myfile,line);
            i=stoi(line);
            while(i){
                getline(myfile,line);
                vec.push_back({"e",line});
                i--;
            }
            j=0;
            while(j<vec.size()){
                outfile<<vec[j][0]<<" "<<vec[j][1]<<endl;
                j++;
            }
            getline(myfile,line);
            num++;
        }
        myfile.close();
        outfile.close();
    }

    else cout << "Unable to open file"; 
    return num;
}

void fsg(string inputfile,string outputfile){
    string line;
    ifstream myfile (inputfile);
    ofstream outfile (outputfile);
    if (myfile.is_open() && outfile.is_open())
    {
        while(getline(myfile,line)){
            vector<vector<string>> vec;
            outfile<<"t"<<endl;
            getline(myfile,line);
            int i=stoi(line);
            while (i)
            {
                getline(myfile,line);
                vec.push_back({"v",line});
                i--;
            }
            int j=0;
            while(j<vec.size()){
                if(vec[j][0]=="v")
                outfile<<vec[j][0]<<" "<<to_string(j)<<" "<<vec[j][1]<<endl;
                j++;
            }
            vec.clear();
            getline(myfile,line);
            i=stoi(line);
            while(i){
                getline(myfile,line);
                vec.push_back({"u",line});
                i--;
            }
            j=0;
            while(j<vec.size()){
                outfile<<vec[j][0]<<" "<<vec[j][1]<<" "<<"E"<<endl;
                j++;
            }
            getline(myfile,line);
        }
        myfile.close();
        outfile.close();
    }

    else cout << "Unable to open file"; 
}

int main(int argc, char* argv[]){
    string command=argv[1];
    string Input_file=argv[2];
    string output_file=argv[3];
    // cout<<command<<endl;
    if(command=="fsg"){
        // cout<<"here"<<endl;
        fsg(Input_file,output_file);
    }
    else{
        cout<<gspanGaston(Input_file,output_file)<<endl;
    }
}