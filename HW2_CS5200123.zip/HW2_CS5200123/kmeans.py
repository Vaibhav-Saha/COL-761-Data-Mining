import numpy as np
import matplotlib.pyplot as plt
import sys
from sklearn.cluster import KMeans

input_data=sys.argv[1]
output_data=sys.argv[2]

data = np.genfromtxt(input_data, delimiter=' ')


k_values = range(1, 16)


inertias = []

for k in k_values:
    kmeans = KMeans(n_clusters=k, random_state=0)
    kmeans.fit(data)
    inertias.append(kmeans.inertia_)

plt.figure(figsize=(8, 6))
plt.plot(k_values, inertias, marker='o', linestyle='-')
plt.title('Elbow Plot for K-means Clustering')
plt.xlabel('Value of K')
plt.ylabel('Sum of Squared distance')
plt.grid(True)

plt.savefig(output_data)

plt.show()
