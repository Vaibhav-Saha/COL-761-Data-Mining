import sys
import subprocess
import time
import matplotlib.pyplot as plt


fsg_dataset = sys.argv[1]
gaston_gspan_dataset = sys.argv[2]
min_support_values = sys.argv[3].split()  
num_graph = sys.argv[4]


gspan_running_times = []
fsg_running_times = []
gaston_running_times = []

for min_support in min_support_values:
    total_graph=float(min_support)*(float(num_graph))
    fsg_min=float(min_support)*100
    gspan_command = f'./gSpan-64 -f {gaston_gspan_dataset} -s {min_support}' 
    fsg_command = f'./fsg -s {str(fsg_min)} {fsg_dataset}' 
    gaston_command = f'./gaston {str(total_graph)} {gaston_gspan_dataset}' 

    start_time = time.time()

    subprocess.call(gspan_command, shell=True)

    end_time = time.time()

    gspan_running_time = end_time - start_time
    gspan_running_times.append(gspan_running_time)

    subprocess.call(fsg_command, shell=True)

    end_time = time.time()

    fsg_running_time = end_time - start_time
    fsg_running_times.append(fsg_running_time)

    subprocess.call(gaston_command, shell=True)

    end_time = time.time()

    gaston_running_time = end_time - start_time
    gaston_running_times.append(gaston_running_time)

plt.figure(figsize=(10, 6))
plt.plot(min_support_values, gspan_running_times, label='gSpan', marker='o')
plt.plot(min_support_values, fsg_running_times, label='FSG', marker='x')
plt.plot(min_support_values, gaston_running_times, label='Gaston', marker='s')


plt.xlabel('Minimum Support')
plt.ylabel('Running Time (seconds)')
plt.legend()
plt.show()
