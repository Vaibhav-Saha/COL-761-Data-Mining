#!/bin/bash

# Compile the C++ program (if not already compiled)

$(module load apps/anaconda/3)

g++ changegraph.cpp -o my_program

$(./my_program fsg $1 fsg.txt_graph)
output=$(./my_program gspan $1 gspan.txt_graph)


fsg_dataset="fsg.txt_graph"
gaston_gspan_dataset="gspan.txt_graph"

# Define the minimum support values
min_support_values="0.05 0.10 0.25 0.5 0.95"

# Call the Python script once and pass both dataset files
python3 plots.py "$fsg_dataset" "$gaston_gspan_dataset" "$min_support_values" "$output"



