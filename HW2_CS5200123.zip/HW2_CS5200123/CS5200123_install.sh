#!/bin/bash

# Default GitHub Repository URL
default_repo_url="https://github.com/Vaibhav-Saha/COL-761-Data-Mining.git"

# Clone the repository
git clone "$default_repo_url" 

# Check if the clone was successful
if [ $? -eq 0 ]; then
  echo "Repository cloned successfully."
else
  echo "Failed to clone repository."
  exit 1
fi

# Change to the cloned "A2" folder
cd COL-761-Data-Mining/

# Optional: List the contents of the cloned "A2" directory
ls
